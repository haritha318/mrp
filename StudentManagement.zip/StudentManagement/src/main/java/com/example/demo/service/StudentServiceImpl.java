package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.model.Student;

@Service
public class StudentServiceImpl implements StudentService
{

	private List<Student> stuList = new ArrayList<Student>();
	
	@Override
	public List<Student> getAllStudents() {
		
		return stuList;
	}

	@Override
	public Student addStudent(Student student) {

		stuList.add(student);
		return student;
	}

}
